package com.example.WebCaptcha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebCaptchaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.WebCaptcha;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ProductDAOService {

	@Autowired
	ProductRepository repo;
	
	//insert product object
	public void createProduct(Product p) {
		repo.save(p);
	}
		
	//retrieve all products
	public List<Product> getAllProducts(){
		
		return repo.findAll();
	}
}


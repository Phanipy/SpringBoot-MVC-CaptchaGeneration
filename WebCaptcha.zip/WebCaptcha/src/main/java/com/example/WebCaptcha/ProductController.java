package com.example.WebCaptcha;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import cn.apiclub.captcha.Captcha;

@Controller
public class ProductController {

	@Autowired
	ProductDAOService pds;
	static String captchaHidden = null;
	
	//Default page for project
	@GetMapping("/")
	public String welcome() {
		return "welcome";
	}
	
	//register the product
	@GetMapping("/register")
	public String register(Model m) {
		Product p = new Product();
		getCaptcha(p);
		System.out.println(p.getRealCaptcha());
		m.addAttribute("command", p);
		return "register";
	}
	
	//save and insert in to database
	@PostMapping("/insertproduct")
	public String insertproduct(@ModelAttribute Product p, Model m) {
		
		if(p.getCaptcha().equals(captchaHidden)) {
			pds.createProduct(new Product(p.getPid(),p.getPname(),p.getQnty(),p.getPrice()));
			return "redirect:/showproducts";
		}else {
			m.addAttribute("message", "Invalid Captcha....");
			Product p1 = new Product();
			getCaptcha(p1);
			m.addAttribute("command", p1);
		
		return "register";}
		
	}
	
	
	//show all the products list
	@GetMapping("/showproducts")
	public String showAll(Model m) {
		
		List<Product> list = pds.getAllProducts();
		
		m.addAttribute("command", list);
		
		return "ShowProducts";
	}
	
	public static void getCaptcha(Product p) {
		Captcha c = CaptchaUtil.createCaptcha(150, 40);
		p.setHiddenCaptcha(c.getAnswer());
		captchaHidden = c.getAnswer();
		p.setCaptcha("");
		String caa = CaptchaUtil.encodeCaptcha(c);
		System.out.println("captha string: "+caa);
		p.setRealCaptcha(caa);
		System.out.print("getcaptcha : '"+p.getCaptcha()+" ','"+p.getHiddenCaptcha()+" ','"+p.getRealCaptcha()+"'");	
	
	}
}


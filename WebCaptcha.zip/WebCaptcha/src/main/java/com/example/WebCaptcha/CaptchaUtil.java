package com.example.WebCaptcha;

import java.io.ByteArrayOutputStream;
import java.util.Base64;

import javax.imageio.ImageIO;

import cn.apiclub.captcha.Captcha;
public class CaptchaUtil {
	public static Captcha createCaptcha(int width,int height) {
		return new Captcha.Builder(width, height)
				.addBackground()
				.addText()
				.addNoise()
				.build();
	}
	public static String encodeCaptcha(Captcha captcha) {
		
			try {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ImageIO.write(captcha.getImage(), "png", baos);
				byte[] byteArray = Base64.getEncoder().encode(baos.toByteArray());
				String image = new String(byteArray);
				return image;
				
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			return null;
		}
}
